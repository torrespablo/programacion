/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg1;
import static java.lang.Math.sqrt;
/**
 *
 * @author Pablo
 */
public class Main {

    public static void main(String[] args) {
        double hipotenusa, cateto1, cateto2;   
        cateto1 = 10;
        cateto2 = 20;
        
        hipotenusa = sqrt((cateto1*cateto1)+(cateto2*cateto2));
        System.out.println(hipotenusa);
    }
    
}

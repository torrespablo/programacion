/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg11;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int numero, resultado;
        
        System.out.println("Introduce un número positivo natural: ");
        numero = escaner.nextInt();
        resultado = 1;
        
        for(int i=numero;i>0;i--){
            resultado = resultado * i;
        }
        System.out.println(resultado);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg13;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numero1, numero2, resultado, i;
        Scanner escaner = new Scanner (System.in);
        
        System.out.println("Introduce un límite inferior: ");
        numero1 = escaner.nextInt();
        System.out.println("Introduce un límite superior: ");
        numero2 = escaner.nextInt();
        resultado = 0;
        i = 0;
        
        for(int j = numero1;j<numero2;j++){
            if(j%2 == 0){
                i++;
                System.out.println(j);
                resultado =+j;
            }
        }
        System.out.println("Contador: " + i);
        System.out.println("Rsultado: " + resultado);
    }
    
}

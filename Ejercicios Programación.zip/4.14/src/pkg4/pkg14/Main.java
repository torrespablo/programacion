/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg14;

/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int cuasiconstante = 1;
        for(int i=0; i<100; i++){
            switch(cuasiconstante){
                case 1: 
                    System.out.println("Hola");
                    cuasiconstante = 2;
                case 2: 
                    System.out.println("Adiós");
                    cuasiconstante = 1;
            }       
        }
    }
    
}

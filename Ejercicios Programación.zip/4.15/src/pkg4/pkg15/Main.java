/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg15;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int numero1, numero2;
        
        System.out.println("Introduce el límite inferior: ");
        numero1 = escaner.nextInt();
        System.out.println("Introduce el límite superior: ");
        numero2 = escaner.nextInt();
        
        for(int i=numero1; i<numero2; i++){
            int contador = 1;
            if(i%3 == 0){
                contador++;
                if(contador%2 == 0){
                System.out.println(i);
                }
            }
        }
    }
    
}

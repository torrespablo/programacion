/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg16;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int n;
        double valormax, valormin;
        double numeros[];
        
        System.out.println("Introduce tamaño de la lista: ");
        n = escaner.nextInt();
        numeros = new double[n];
        valormax = 0;
        valormin = 0;
        
        for(int i=0; i<n; i++){
            System.out.println("Introduce un número: ");
            numeros[i] = escaner.nextDouble();
            if(numeros[i] < valormin){
                valormin = numeros[i];
            }
            if(numeros[i] > valormax){
                valormax = numeros[i];
            }
        }
        System.out.println("Valor máximo: " + valormax);
        System.out.println("Valor mínimo: " + valormin);
    }
    
}

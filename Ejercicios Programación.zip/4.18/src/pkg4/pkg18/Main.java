/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg18;
import java.util.Scanner;
import static java.lang.Math.sqrt;

/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int A, B, result, factorialA, factorialB,factorialAB, numero;
        
        System.out.println("Introduce valor A:");
        A = escaner.nextInt();
        System.out.println("Introduce valor B: ");
        B = escaner.nextInt();
        factorialA = 1;
        factorialB = 1;
        factorialAB = 1;
        
        numero = A;
        while(numero != 0){
            factorialA = factorialA*numero;
            numero--;
        }
        
        numero = B;
        while(numero != 0){
            factorialB = factorialB*numero;
            numero--;
        }
        
        numero = A - B;
        while(numero != 0){
            factorialAB = factorialAB*numero;
            numero--;
        }
        
        result = (factorialA)/(factorialB*factorialAB);
        System.out.println("Rsultado: " + result);
    }
    
}

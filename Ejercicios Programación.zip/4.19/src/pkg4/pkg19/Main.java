/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg19;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int numero, positivos, negativos;
        negativos = 0;
        positivos = 0;

        System.out.println("Introduce un número: ");
        numero = escaner.nextInt();
        while(numero != 0){
            if(numero < 0){
                negativos++;
            }
            if(numero > 0){
                positivos++;
            }
            System.out.println("Introduce un número: ");
            numero = escaner.nextInt();
        }
        System.out.println("Positivos: " + positivos);
        System.out.println("Negativos: " + negativos);
    }
    
}

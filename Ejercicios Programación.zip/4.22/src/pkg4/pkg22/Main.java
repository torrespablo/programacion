/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg22;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner(System.in);
        int numero, contador;
        boolean esprimo = true;
        contador = 2;
        
        
        System.out.println("Introduce un número: ");
        numero = escaner.nextInt();
        
        while(esprimo && contador != numero){
            if(numero % contador == 0){
                esprimo = false;
            }
            contador++;
        }
        
        if(esprimo){
            System.out.println("El número es primo.");
        } else{
            System.out.println("el número no es primo.");
        }
        
        
        
    }
    
}

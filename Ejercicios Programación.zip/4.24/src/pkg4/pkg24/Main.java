/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg24;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        double nota;
        
        System.out.println("Introduce tu nota: ");
        nota = escaner.nextDouble();
        
        if(nota < 0 || nota > 10){
            System.out.println("Error");
        } else{
            if(nota >= 0 && nota < 3){
                System.out.println("Muy deficiente");
            }
            if(nota >= 3 && nota < 5){
                System.out.println("Insuficiente");
            }
            if(nota >= 5 && nota < 6){
                System.out.println("Suficiente");
            }
            if(nota >= 6 && nota < 7){
                System.out.println("Bien");
            }
            if(nota >= 7 && nota < 9){
                System.out.println("Notable");
            }
            if(nota >= 9 && nota <= 10){
                System.out.println("Sobresaliente");
            }            
        }
    }  
}

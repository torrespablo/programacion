/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg25;
import java.util.Scanner;

/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        double nota;
        int estadistica[];
        
        estadistica = new int[5];
        
        System.out.println("Introduce notas (0 para salir): ");
        nota = escaner.nextDouble();
        
        while(nota != 0){
            if(nota > 1 && nota < 5){
                estadistica[0]++;
            }
            if(nota >= 5 && nota < 6){
                estadistica[1]++;
            }
            if(nota >= 6 && nota < 7){
                estadistica[2]++;
            }
            if(nota >= 7 && nota < 9){
                estadistica[3]++;
            }
            if(nota >= 9 && nota < 10){
                estadistica[4]++;
            }
            
            System.out.println("Introduce notas (0 para salir): ");
            nota = escaner.nextDouble();
        }
        
        System.out.println("Deficientes: " + estadistica[0]);
        System.out.println("Suficientes: " + estadistica[1]);
        System.out.println("Bien: " + estadistica[2]);
        System.out.println("Notables: " + estadistica[3]);
        System.out.println("Sobresalientes: " + estadistica[4]);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg26;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int opcion;
        int numeroaleatorio;
        
        System.out.println("Escribe cualquier numero para jugar, 0 para salir: ");
        opcion = escaner.nextInt();
        
        while(opcion != 0){
            numeroaleatorio = (int) (Math.random()*2);
            if(numeroaleatorio == 0){
                System.out.println("Cara");
            }
            if(numeroaleatorio == 1){
                System.out.println("Cruz");
            }
            System.out.println("Escribe cualquier numero para jugar, 0 para salir: ");
            opcion = escaner.nextInt();            
        }
        
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg27;

/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numeroaleatorio;
        int contador = 0;
        for(int i=0;i<=100;i++){
            numeroaleatorio = (int) ((Math.random()*6) + 1);
            if(numeroaleatorio == 6){
                contador++;
            }
        }
        System.out.println("El número 6 ha aparecido " + contador + " veces.");
    }
    
}

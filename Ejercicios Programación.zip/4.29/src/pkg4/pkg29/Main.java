/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg29;

/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char resultado = 1;
        int numeroaleatorio;
        
        numeroaleatorio = (int) ((Math.random()*10) + 1);
        if(numeroaleatorio >= 0 && numeroaleatorio <= 2){
            resultado = '2';
        }
        if(numeroaleatorio > 2 && numeroaleatorio <= 5){
            resultado = 'x';
        }
        if(numeroaleatorio > 5 && numeroaleatorio <= 10){
            resultado = '1';
        }
        
        System.out.println("Ha salido " + resultado);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg3;
import static java.lang.Math.sqrt;
import java.util.Scanner;

/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner escaner = new Scanner (System.in);
        double s1, s2, s3, area, t;
        
        System.out.println("Introduce lado 1 del triángulo: ");
        s1 = escaner.nextDouble();
        System.out.println("Introduce lado 2 del triángulo: ");
        s2 = escaner.nextDouble();
        System.out.println("Introduce lado 3 del triángulo: ");
        s3 = escaner.nextDouble();

        t = (s1 + s2 + s3)/2;
        
        area = sqrt(t*(t-s1)*(t-s2)*(t-s3));
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg30;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int opcion;
        
        System.out.println("Introduce 1 para jugar, cualquier otro para salir: )");
        opcion = escaner.nextInt();
        
        while(opcion == 1){
            int guess;
            int numeroaleatorio = (int) ((Math.random()*100)+1);

            for(int intentos=5;intentos>=0;intentos--){
                System.out.println("Tienes " + intentos + " intentos.");                
                
                System.out.println("Introduce tu intento: ");
                guess = escaner.nextInt();
                
                if(guess == numeroaleatorio){
                    System.out.println("¡Correcto!");
                }else{
                    if(guess > numeroaleatorio){
                        System.out.println("El número es menor al introducido.");
                    }else{
                        System.out.println("El número es mayor al introducido.");
                    }
                }
            }
            
            System.out.println("Introduce 1 para jugar, cualquier otro para salir: )");
            opcion = escaner.nextInt();  
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg6;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double numero1, numero2;
        Scanner escaner = new Scanner (System.in);
        
        System.out.println("Introduce un número: ");
        numero1 = escaner.nextDouble();
        System.out.println("Introduce un número: ");
        numero2 = escaner.nextDouble();
        
        if(numero1%numero2 == 0){
            System.out.println(numero1 + " divide de forma entera a " + numero2);
        } else if(numero2%numero1 ==0){
            System.out.println(numero2 + " divide de forma entera a " + numero1);
        } else{
            System.out.println("No pueden dividirse de forma entera.");
        }
    }
    
}

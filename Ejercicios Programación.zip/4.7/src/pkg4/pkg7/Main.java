/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg7;
import java.util.Scanner;

/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        double numero1, numero2, numero3;
        
        System.out.println("Introduce un número: ");
        numero1 = escaner.nextDouble();
        System.out.println("Introduce un número: ");
        numero2 = escaner.nextDouble();
        System.out.println("Introduce un número: ");
        numero3 = escaner.nextDouble();
        
        if(numero1 >= numero2){
            if(numero1 >= numero3){
                System.out.println(numero1 + " es el mayor.");
            } else if(numero3 >= numero1){
                System.out.println(numero3 + " es el mayor.");
            }
        } else if(numero2 >= numero3){
                System.out.println(numero2 + " es el mayor.");
             if(numero3 >= numero2){
                System.out.println(numero3 + " es el mayor.");
            }
        }
    }
}
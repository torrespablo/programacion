/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg4.pkg8;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        double a = 0, b = 0, c = 0, a2, b2, c2;
        
        System.out.println("Introduce un lado: ");
        a2 = escaner.nextDouble();
        System.out.println("Introduce un lado: ");
        b2 = escaner.nextDouble();
        System.out.println("Introduce otro lado: ");
        c2 = escaner.nextDouble();
        
        if(a2 >= b2){
            if(a2 >= c2){
                a = a2;
                c = b2;
                b = c2;
            } else if(c2 >= a2){
                a = c2;
                b = a2;
                c = b2;
            }
        } else if(b2 >= c2){
                a = b2;
                b = a2;
                c = c2;
             if(c2 >= b2){
                 a = c2;
                 b = a2;
                 c = b2;
            }
        }
        
        if(a >= (b+c)){
            System.out.println("No es triángulo.");
        }
        if((a*a) == ((b*b)+(c*c))){
            System.out.println("Triángulo rectángulo.");
        }
        if((a*a) > ((b*b)+(c*c))){
            System.out.println("Triángulo obtusángulo.");
        }
        if((a*a) < ((b*b)+(c*c))){
            System.out.println("Triángulo acutángulo.");
        }
    }
    
}

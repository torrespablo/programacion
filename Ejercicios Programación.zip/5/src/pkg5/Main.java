/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg5;
import java.util.Scanner;

class Main{
    
    public static void main(String[] args) {
        Urna.Urna();
    }
}

class Urna{
    
    static void Urna(){
        Scanner escaner = new Scanner (System.in);
        int bnegras, bblancas, urna;
        int random1, random2;
        boolean bola1, bola2;
        
        System.out.println("Introduce el número de bolas negras: ");
        bnegras = escaner.nextInt();
        System.out.println("Introduce el número de bolas blancas: ");
        bblancas = escaner.nextInt();
        urna = bnegras + bblancas;
        
        while(urna > 1){
            random1 =(int) (Math.random()*(urna-1)+1);
            random2 =(int) (Math.random()*(urna-1)+1);
            if(random1 <= bnegras){
                bola1 = false;
                urna--;
                bnegras--;
            } else{
                bola1 = true;
                urna--;
                bblancas--;
            }
            if(random2 <= bnegras){
                bola2 = false;
                urna--;
                bnegras--;
            } else{
                bola2 = true;
                urna--;
                bblancas--;
            }
            
            if(bola1 == bola2){
                urna++;
                bnegras++;
            }else{
                urna++;
                bblancas++;
            }
            if(bola1 ==  true){
                System.out.println("Bola 1 = Blanca");
            }else{
                System.out.println("Bola 1 = Negra");
            }
            if(bola2 ==  true){
                System.out.println("Bola 2 = Blanca");
            }else{
                System.out.println("Bola 2 = Negra");
            }
            if(urna == 1){
                if(bblancas == 1) System.out.println("Última bola = Blanca");
                if(bnegras == 1) System.out.println("Última bola = Negra");
            }
        }        
    }
}

class UrnaTrampa{
    
    static void UrnaTrampa(){
        Scanner escaner = new Scanner (System.in);
        int bnegras, bblancas, urna;
        int random1, random2;
        boolean bola1, bola2;
        
        System.out.println("Introduce el número de bolas negras: ");
        bnegras = escaner.nextInt();
        System.out.println("Introduce el número de bolas blancas: ");
        bblancas = escaner.nextInt();
        urna = bnegras + bblancas;
        
        while(urna > 1){
            random1 =(int) (Math.random()*(urna-1)+1);
            random2 =(int) (Math.random()*(urna-1)+1);
            if(random1 <= bnegras){
                bola1 = false;
                bnegras--;
                if(Math.random()*100 <= 0.2){
                    if(bnegras >= bblancas){
                        bnegras--;
                        bblancas++;
                    }else{
                        bblancas--;
                        bnegras++;
                    }
                }
            } else{
                bola1 = true;
                urna--;
                bblancas--;
                if(Math.random()*100 <= 0.2){
                    if(bnegras >= bblancas){
                        bnegras--;
                        bblancas++;
                    }else{
                        bblancas--;
                        bnegras++;
                    }
                }                
            }
            if(random2 <= bnegras){
                bola2 = false;
                urna--;
                bnegras--;
                if(Math.random()*100 <= 0.2){
                    if(bnegras >= bblancas){
                        bnegras--;
                        bblancas++;
                    }else{
                        bblancas--;
                        bnegras++;
                    }
                }
            } else{
                bola2 = true;
                urna--;
                bblancas--;
                if(Math.random()*100 <= 0.2){
                    if(bnegras >= bblancas){
                        bnegras--;
                        bblancas++;
                    }else{
                        bblancas--;
                        bnegras++;
                    }
                }
            }
            
            if(bola1 == bola2){
                urna++;
                bnegras++;
            }else{
                urna++;
                bblancas++;
            }
            if(bola1 ==  true){
                System.out.println("Bola 1 = Blanca");
            }else{
                System.out.println("Bola 1 = Negra");
            }
            if(bola2 ==  true){
                System.out.println("Bola 2 = Blanca");
            }else{
                System.out.println("Bola 2 = Negra");
            }
            if(urna == 1){
                if(bblancas == 1) System.out.println("Última bola = Blanca");
                if(bnegras == 1) System.out.println("Última bola = Negra");
            }
        }        
    }      
}

class Matematica{
    
    static int Factorial(int numero){
            int resultado;
            resultado = 0;
            
            for(int i=numero-1;i>0;i--){
                resultado += i;
            }
            
            return resultado;
    }
    
    static boolean Primo(int numero){
        int contador;
        boolean esprimo = true;
        contador = 2;
        
        while(esprimo && contador != numero){
            if(numero % contador == 0){
                esprimo = false;
            }
            contador++;
        }
        
        return esprimo;
    }
    
    static int Perfecto(int numero){
        int resultado;
        resultado = 0;
        for(int i=0;i<numero;i++){
            if(numero%i == 0){
                resultado += i;
            }
        }
        
        return resultado;
    }
    
    static boolean Amigos(int numero1, int numero2){
        boolean amigos;
        int suma1, suma2;
        suma1 = 0;
        suma2 = 0;
        
        for(int i=0;i<numero1;i++){
            if(numero1 % i == 0){
                suma1 += i;
            }
        }
        
        for(int i=0;i<numero2;i++){
            if(numero2 % i == 0){
                suma2 += i;
            }
        }

        if(suma2 == numero1 && suma1 == numero2){
            amigos = true;
        }else{
            amigos = false;
        }
        
        return amigos;
    }
    
    
    
}
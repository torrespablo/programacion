/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casino;
import java.util.Scanner;

/**
 *
 * @author Pablo
 */
public class Casino {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int capital;
        Scanner escaner = new Scanner (System.in);
        
        System.out.println("Introduce el capital inicial: ");
        capital = escaner.nextInt();
        

        for(int i=0; i<100000; i++){
            capital += CasiIguales();
        }
        System.out.println("CASI IGUALES PERO NO TANTO: " + capital);

        for(int i=0; i<100000; i++){
            capital += PorTres(capital);
        }
        System.out.println("POR TRES ES AL REVÉS: " + capital);
        
        for(int i=0; i<400000;i++){
            for(int j=0;j<4;j++){
                if(j<2){
                    capital += CasiIguales();
                }else{
                    capital += PorTres(capital);
                }
            }
        }
        System.out.println("MEZCLANDO JUEGOS: " + capital);
    }
    
    public static int CasiIguales(){
        boolean moneda;
        double probabilidad = Math.random()*100;
        
        if(probabilidad <= 49.5){
            moneda = true;
        } else{
            moneda = false;
        }
        if(moneda){
            return 1;
        }else{
            return -1;
        }
    }
    
    public static int PorTres(int capital){
        boolean moneda;
        double probabilidad = Math.random()*100;
        if(capital%3 == 0){
            if(probabilidad <= 9.5){
                moneda = true;
            }else{
                moneda = false;
            }
        }else{
            if(probabilidad <= 75.5){
                moneda = true;
            }else{
                moneda = false;
            }
        }
        if(moneda){
            return 1;
        }else{
            return -1;
        }
    }   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuadradosmagicos;
import java.util.Scanner;
/**
 *
 * @author Pablo
 * Tócate los cojones Mariloli lo que nos ha tocado hacer
 */
public class CuadradosMagicos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int[][] matriz;
        int tamanio;
        int contador = 0;
        int comprobante = 0;
        boolean esmagico = false;
        
        System.out.println("Introduce el tamaño de la matriz: ");
        tamanio = escaner.nextInt();
        matriz = new int[tamanio][tamanio];
        
        for(int i=0;i<tamanio;i++){
            for(int j=0;j<tamanio;j++){
                System.out.println("Introduce un número: ");
                matriz[i][j] = escaner.nextInt();
            }
        }
        
        for(int i=0;i<tamanio;i++){
            comprobante += matriz[0][i];
        }
        
        for(int i=0;i<tamanio;i++){
            contador = 0;
            for(int j=0;j<tamanio;j++){
                contador += matriz[i][j];
            }
            if(contador == comprobante){
                esmagico = true;
            }else{
                esmagico = false;
                break;
            }            
        }
        contador = 0;
        
        if(esmagico == true){
            for(int i=0;i<tamanio;i++){
                contador = 0;
                for(int j=0;j<tamanio;j++){
                    contador += matriz[j][i];
                }
                if(contador == comprobante){
                    esmagico = true;
                }else{
                    esmagico = false;
                    break;
                }                
            }
        }
        contador = 0;
        
        if(esmagico == true){
            for(int i=0;i<tamanio;i++){
                contador += matriz[i][i];
            }
            if(contador == comprobante){
                esmagico = true;
            }else{
                esmagico = false;
                }
        }
        contador = 0;
        
        if(esmagico == true){
            for(int i=tamanio;i<tamanio;i--){
                contador = 0;
                for(int j=0;j<tamanio;j++){
                        contador += matriz[i][j];
                    }
                if(contador == comprobante){
                    esmagico = true;
                }else{
                    esmagico = false;
                    break;
                }

            }
        }
        
        if(esmagico == true){
            System.out.println("La matriz es un cuadrado mágico.");
        }else{
            System.out.println("La matriz no es un cuadrado mágico.");
        }  
    } 
}

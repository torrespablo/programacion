/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciocadenas;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class EjercicioCadenas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        String cadena1;
        String cadena2;
        boolean tipocadena;
        
        System.out.println("Introduce la primera cadena: ");
        cadena1 = escaner.nextLine();
        
        System.out.println("Introduce la segunda cadena: ");
        cadena2 = escaner.nextLine();
        
        int tamano1, tamano2, contador;
        
        tamano1 = cadena1.length();
        tamano2 = cadena2.length();
        
        if(tamano1 >= tamano2){
            tipocadena = true;
            contador = tamano2-1;
            for(int i=1;i<tamano1;i++){
                for(int j=1;j<tamano2;j++){
                    if(cadena1.charAt(i) == cadena2.charAt(j) && cadena1.charAt(i-1) == cadena2.charAt(j-1)){
                        contador--;
                    }
                }
            }
        }else{
            tipocadena = false;
            contador = tamano1-1;
            for(int i=1;i<tamano2;i++){
                for(int j=1;j<tamano1;j++){
                    if(cadena2.charAt(i) == cadena1.charAt(j) && cadena2.charAt(i-1) == cadena1.charAt(j-1)){
                        contador--;            
                    }
                }
            }
        }
        if(contador == 0){
            if(tipocadena == true){
                System.out.println("La cadena "+ cadena2 + " es subcadena de " + cadena1 + ".");
            }else{
                System.out.println("La cadena "+ cadena1 + " es subcadena de " + cadena2 + ".");
            }
        }else{
            System.out.println("No hay subcadenas.");
        }
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioconejos;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class EjercicioConejos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int meses, total, anterior, aanterior;
        total = 1;
        anterior = 0;
        
        System.out.println("Introduce el número de meses treanscurridos: ");
        meses = escaner.nextInt();
        if(meses >= 2){
            for(;meses-1 > 0; meses--){
                aanterior = anterior;
                anterior = total;
                total = aanterior + anterior;
            }
            System.out.println("El número total de parejas de conejos es " + total);
        }
        else{
            System.out.println("El número total de parejas de conejos es " + total);
        }
    }
}

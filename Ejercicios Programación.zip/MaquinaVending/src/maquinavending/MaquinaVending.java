package maquinavending;
import java.util.Scanner;

/**
 *
 * @author Pablo
 */
public class MaquinaVending {
    
    public static int[] devuelveCambio(double importeIntroducido, double precio){
        double cambio = importeIntroducido - precio;
        int tipoMonedas [];
        tipoMonedas= new int[8];

        while(cambio >= 0){
            if(cambio >=2){
                cambio = cambio - 2.00;
                tipoMonedas[0]++;
            }
            else if(cambio >=1){
                cambio = cambio - 1.00;
                tipoMonedas[1]++;
            }else if(cambio >= .50){
                cambio = cambio - .50;
                tipoMonedas[2]++;
            }else if(cambio >= .20){
                cambio = cambio - .20;
                tipoMonedas[3]++;                
            }else if(cambio >= .10){
                 cambio = cambio - .10;
                tipoMonedas[4]++;               
            }else if(cambio >= .05){
                cambio = cambio - .05;
                tipoMonedas[5]++;                
            }else if(cambio >= .02){
                 cambio = cambio - .02;
                tipoMonedas[6]++;               
            }else if(cambio >= .01){
                cambio = cambio - .01;
                tipoMonedas[7]++;                
            }
        }
        return tipoMonedas;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        boolean salir = false;
        Scanner entradaEscaner = new Scanner (System.in);
        double precio = 0;
        double importeIntroducido = 0;

        while(!salir){
            int monedas[] = null;
            System.out.println("Por favor, indique la opción que desea: ");
            String entradaTeclado = "";
            entradaTeclado = entradaEscaner.nextLine ();
            
            if(null == entradaTeclado){
                System.out.println("Se ha equivocado.Introduzca por favor la opción correcta.");
                System.out.println("Opciones correctas: refresco, agua, salir.");
            }else switch (entradaTeclado){
                case "refresco":
                    System.out.println("Por favor, introduzca la cantidad en la máquina: ");
                    importeIntroducido = entradaEscaner.nextDouble();
                    precio = 1.20;
                    monedas = devuelveCambio(importeIntroducido, precio);
                    break;
                case "agua":
                    System.out.println("Por favor, introduzca la cantidad en la máquina: ");
                    importeIntroducido = entradaEscaner.nextDouble();
                    precio = 0.70;
                    monedas = devuelveCambio(importeIntroducido, precio);
                    break;
                case "salir":
                    System.out.println("Gracias por utilizar nuestro programa.");
                    salir = true;
                    break;
                default:
                    System.out.println("Se ha equivocado.Introduzca por favor la opción correcta.");
                    System.out.println("Opciones correctas: refresco, agua, salir.");
                    break;
            }
            //Ahora imprimimos el cambio
            if(monedas != null){
                System.out.println("Su cambio es de:");
                System.out.println("Monedas de 2 euros: " + monedas[0]);
                System.out.println("Monedas de 1 euros: " + monedas[1]);
                System.out.println("Monedas de 50 céntimos: " + monedas[2]);
                System.out.println("Monedas de 20 céntimos: " + monedas[3]);
                System.out.println("Monedas de 10 céntimos: " + monedas[4]);
                System.out.println("Monedas de 5 céntimos: " + monedas[5]);
                System.out.println("Monedas de 2 céntimos: " + monedas[6]);
                System.out.println("Monedas de 1 céntimo: " + monedas[7]);
            }
        }
    }
}

        




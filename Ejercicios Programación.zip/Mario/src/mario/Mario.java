/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mario;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Mario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int ncasos, nmuros, muro, hJumps, lJumps, altAnt;
        
        System.out.println("Introduce el número de casos: ");
        ncasos = escaner.nextInt();
        String[] casos = new String[ncasos];
        for(int i=1;i<ncasos+1;i++){
            hJumps = 0;
            lJumps = 0;
            altAnt = 0;
            System.out.println("Introduce el número de muros: ");
            nmuros = escaner.nextInt();
            for(int j=0;j<nmuros;j++){
                muro = escaner.nextInt();
                if(j>=1){
                    if(muro < altAnt){
                        lJumps ++;
                    }else if(muro > altAnt){
                        hJumps++;
                    }
                }
                altAnt = muro;
            }
            System.out.println("Caso " + i + ": " + hJumps + " " + lJumps);
        }
    }
}

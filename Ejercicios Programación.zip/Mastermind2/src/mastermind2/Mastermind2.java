/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mastermind2;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Mastermind2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int[] numeroSecreto = new int[4];
        int[] numeroJugador = new int[4];
        int nivel;
        int intentos = 0;
        boolean victoria = false;
        
        for(int i=0;i<4;i++){
            numeroSecreto[i] =(int) (Math.random()*10);
            numeroJugador[i] = 0;
            
            if(numeroSecreto[i] >= 10){
                numeroSecreto[i] = 9;
            }
        }
        
        System.out.print("Introduce nivel de dificultad 1, 2 o 3: ");
        nivel = escaner.nextInt();
        switch(nivel){
            case 1:
                intentos = 8;
                break;
            case 2:
                intentos = 6;
                break;
            case 3:
                intentos = 4;
                break;
            default:
                System.out.println("Nivel no reconocido.");
                break;
        }
        
        while (intentos > 0 || !victoria){
            int aciertoCorrecto = 0;
            int aciertoIncorrecto = 0;
            System.out.println("Intentos: " + intentos);
            
            System.out.println("La primera cifra: ");
            numeroJugador[0] = escaner.nextInt();
            System.out.println("La segunda cifra: ");
            numeroJugador[1] = escaner.nextInt();
            System.out.println("La tercera cifra: ");
            numeroJugador[2] = escaner.nextInt();
            System.out.println("La cuarta cifra: ");
            numeroJugador[3] = escaner.nextInt();
            
            for(int i=0;i<3;i++){
                for(int j=0;j<3;j++){
                    if(numeroSecreto[i] == numeroJugador[j]){
                        if(j == i){
                            aciertoCorrecto++;
                        }else{
                            aciertoIncorrecto++;
                        }
                    }
                }
            }
            System.out.println("Dígitos en la posición correcta: " + aciertoCorrecto);
            System.out.println("Dígitos en la posición incorrecta: " + aciertoIncorrecto);
            if(aciertoCorrecto == 4){
                victoria = true;
            }
            intentos--;
        }
        if(victoria){
            System.out.println("¡Has ganado! Felicidades.");
        }
        
    }   
}
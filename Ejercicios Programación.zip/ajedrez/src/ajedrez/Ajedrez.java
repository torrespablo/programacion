/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ajedrez;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Ajedrez {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int[] blancas = new int[6];
        int[] negras = new int[6];
        int posicion = 0;
        String pieza;
        String color;
        
        for(int i=0;i<6;i++){
            blancas[i] = 0;
            negras [i] = 0;
        }
        
        while(posicion < 64){
            System.out.println("Introduce el tipo de pieza en la posición " + posicion + " ('none' si la casilla está vacía, no uses acentos ni mayúsculas): ");
            pieza = escaner.next();
            if(!pieza.equals("none")){
                System.out.println("¿De qué color es la pieza?");
                color = escaner.next();
                if(color.equals("blanca") || color.equals("blanco")){
                    switch (pieza) {
                        case "rey":
                            blancas[0]++;
                            break;
                        case "reina":
                            blancas[1]++;
                            break;
                        case "torre":
                            blancas[2]++;
                            break;
                        case "caballo":
                            blancas[3]++;
                            break;
                        case "alfil":
                            blancas[4]++;
                            break;
                        case "peon":
                            blancas[5]++;
                            break;
                        default:
                            System.out.println("Entrada no reconocida");
                            break;
                    }
                }else if(color.equals("negra") || color.equals("negro")){
                     switch (pieza) {
                        case "rey":
                            negras[0]++;
                            break;
                        case "reina":
                            negras[1]++;
                            break;
                        case "torre":
                            negras[2]++;
                            break;
                        case "caballo":
                            negras[3]++;
                            break;
                        case "alfil":
                            negras[4]++;
                            break;
                        case "peon":
                            negras[5]++;
                            break;
                        default:
                            System.out.println("Entrada no reconocida");
                            break;
                    }
                }else{
                    System.out.println("Entrada no reconocida");
                }
            }
            
            posicion++;
        }
        System.out.println("Blancas: ");
        System.out.println("Rey: " + blancas[0]);
        System.out.println("Reina: " + blancas[1]);
        System.out.println("Torre: " + blancas[2]);
        System.out.println("Caballo: " + blancas[3]);
        System.out.println("Alfil: " + blancas[4]);
        System.out.println("Peón: " + blancas[5]);
        System.out.println("Total blancas: " + (blancas[0] + blancas[1] + blancas[2] + blancas[3] + blancas[4] + blancas[5]));
        
        System.out.println("Negras: ");
        System.out.println("Rey: " + negras[0]);
        System.out.println("Reina: " + negras[1]);
        System.out.println("Torre: " + negras[2]);
        System.out.println("Caballo: " + negras[3]);
        System.out.println("Alfil: " + negras[4]);
        System.out.println("Peón: " + negras[5]);
        System.out.println("Total negras: " + (negras[0] + negras[1] + negras[2] + negras[3] + negras[4] + negras[5]));
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ciclomasgrande;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Ciclomasgrande {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaner = new Scanner (System.in);
        int contador, superior, inferior;
        int i = 0;
        int[] limite1 = new int[100];
        int[] limite2 = new int[100];
        int[] mayorciclo = new int[100];
        
        System.out.println("Introduce un número (-1 para salir): ");
        limite1[i] = escaner.nextInt();
        if(limite1[i] != -1){
            System.out.println("introduce otro número: ");
            limite2[i] = escaner.nextInt();
            
            if(limite1[i] >= limite2[i]){
            superior = limite1[i];
            inferior = limite2[i];
            }else{
            superior = limite2[i];
            inferior = limite1[i];
            }
            
            int ciclo;
            for(contador = inferior; contador < superior; contador++){
                int n = contador;
                ciclo = 1;
                while(n > 1){
                    if(n%2 == 0){
                        n = n/2;
                    }else{
                        n = 3*n + 1;
                    }   
                    ciclo++;
                }
            
                if(ciclo >= mayorciclo[i]){
                    mayorciclo[i] = ciclo;
                }
            }
            i++;
        }
        
        while(limite1[i-1] != -1){;
            
            System.out.println("Introduce un número (-1 para salir): ");
            limite1[i] = escaner.nextInt();
            if(limite1[i] != -1){
                System.out.println("introduce otro número: ");
                limite2[i] = escaner.nextInt();
            }
        
            if(limite1[i] >= limite2[i]){
            superior = limite1[i];
            inferior = limite2[i];
            }else{
            superior = limite2[i];
            inferior = limite1[i];
            }
            
            int ciclo;
            for(contador = inferior; contador < superior; contador++){
                int n = contador;
                ciclo = 1;
                while(n > 1){
                    if(n%2 == 0){
                        n = n/2;
                    }else{
                        n = 3*n + 1;
                    }   
                    ciclo++;
                }
            
                if(ciclo >= mayorciclo[i]){
                    mayorciclo[i] = ciclo;
                }
            }
            i++;
        }
        
        for(int j = 0; j < i-1; j++){
            System.out.println(limite1[j] +" "+ limite2[j] +" "+ mayorciclo[j]);
        }
    }
}

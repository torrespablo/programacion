/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg6.pkg1;

/**
 *
 * @author Pablo
 */
public class Caracter {
    
    public static int ordinal(char c){
        return ((int) c);
    }
    
    public static char ascii(int i){
        return ((char) i);
    }
}

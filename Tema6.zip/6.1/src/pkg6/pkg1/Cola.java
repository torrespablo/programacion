/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg6.pkg1;

/**
 *
 * @author Pablo
 */
public class Cola {
    Lista cola = new Lista();
    
    public Object extraeDeCola(){
        return cola.extraeUltimo();
    }
    
    public void ponEnCola(Object ob){
        cola.PonUltimo(ob);
    }
    
    public void vacia(){
        cola.lista.removeAllElements();
    }
    
    public Object frente(){
        return cola.lista.elementAt(0);
    }
}

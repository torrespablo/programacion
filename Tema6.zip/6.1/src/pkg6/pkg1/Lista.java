/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg6.pkg1;
import java.util.Vector;

/**
 *
 * @author Pablo
 */
public class Lista {
    Vector lista = new Vector();
    
    
    public Lista(){
        Vector lista = new Vector();
    }
    
    public void PonPrimero(Object ob){
        lista.insertElementAt(ob, 0);
    }
    
    public void PonUltimo(Object ob){
        lista.addElement(ob);
    }
    
    public boolean estaVacia(){
        return lista.isEmpty();
    }
    
    public Object extraeUltimo(){
        Object objeto = lista.lastElement();
        lista.removeElement(lista.lastElement());
        return objeto;
    }
    
    public void visualizaElementos(){
        for(int i=0;i<lista.size();i++){
            System.out.println(lista.elementAt(i));
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg6.pkg1;
import java.util.Scanner;
/**
 *
 * @author Pablo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Lista lista = new Lista();
        Scanner escaner = new Scanner (System.in);
   
        System.out.println("Prueba de Lista (con enteros)");
        
        System.out.println("Introduce primero: ");
        lista.PonPrimero(escaner.nextInt());
        System.out.println("Introduce último: ");
        lista.PonUltimo(escaner.nextInt());
        
        if(lista.estaVacia()) System.out.println("La lista está vacía.");
        
        lista.visualizaElementos();
        
        System.out.println("Extrae Último: " + lista.extraeUltimo());
        
        lista.visualizaElementos();
        
        //----------------------------------------------------------------------
        System.out.println("Prueba de Pila (con enteros)");
        Pila pila = new Pila();
        
        System.out.println("Introduce valor para push(): ");
        pila.push(escaner.nextInt());
        System.out.println("Cima: " + pila.cima());
        pila.pop();
        pila.push(escaner.nextInt());
        pila.vacia();
        
        //----------------------------------------------------------------------
        System.out.println("Prueba de Cola (con enteros)");
        Cola cola = new Cola();
        
        System.out.println("Introduce valor para ponEnCola(): ");
        cola.ponEnCola(escaner.nextInt());
        System.out.println("Frente: " + cola.frente());
        System.out.println("Extrae de Cola: " + cola.extraeDeCola());
        cola.vacia();
    }
    
}
